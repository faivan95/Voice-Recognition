import demo.sphinx.helloworld.ProjectFrame;

public class VoiceProgramRun {
	public static void main(String[] args)
	{
		ProjectFrame pf = new ProjectFrame();
	}
}