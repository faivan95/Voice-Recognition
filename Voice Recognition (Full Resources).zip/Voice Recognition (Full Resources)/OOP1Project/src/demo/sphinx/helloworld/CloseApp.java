package demo.sphinx.helloworld;

import java.io.IOException;

public class CloseApp {
	Process p;
	
	CloseApp()
	{
		
	}
	
	public void closeApp(String s)
	{
		try {
			//Close Calculator
			if (s.equals("calculator"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im calc.exe /f");
			}
			//Close Windows Media Player
			else if (s.equals("player"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im wmplayer.exe /f");
			}
			//Close Paint
			else if (s.equals("paint"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im mspaint.exe /f");
			}
			//Close Browser
			else if (s.equals("browser"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im chrome.exe /f");
			}
			//Close Facebook
			else if (s.equals("facebook"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im chrome.exe /f");
			}
			//Close Google
			else if (s.equals("google"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im chrome.exe /f");
			}
			//Close Mail
			else if (s.equals("mail"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im chrome.exe /f");
			}
			//Close Notepad
			else if (s.equals("notepad"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im notepad.exe /f");
			}
			//Close Microsoft Word
			else if (s.equals("word"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im winword.exe /f");
			}
			//Close My Computer
			else if (s.equals("explorer"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im explorer.exe /f");
			}
			//Close Excel
			else if (s.equals("excel"))
			{
				p = Runtime.getRuntime().exec("cmd /c start taskkill /im excel.exe /f");
			}
		}
		catch (IOException ioe)
		{
			System.out.println(ioe);
		}
	}
}