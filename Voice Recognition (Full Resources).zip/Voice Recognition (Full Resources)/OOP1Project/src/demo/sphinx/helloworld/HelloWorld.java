package demo.sphinx.helloworld;

import java.net.URL;
import java.sql.ResultSet;
import edu.cmu.sphinx.frontend.util.Microphone;
import edu.cmu.sphinx.recognizer.Recognizer;
import edu.cmu.sphinx.result.Result;
import edu.cmu.sphinx.util.props.ConfigurationManager;

public class HelloWorld 
{
	ProjectFrame pf;
	static String resultText;
	
    public HelloWorld(ProjectFrame f) 
    {
    	this.pf = f;    	
    }
    
    public void voiceStart()
    {
    	DataAccess da=new DataAccess();
        ResultSet rs=null;
        RunApp ra = new RunApp();
        CloseApp ca = new CloseApp();
        
		try { 
			URL url;
			url = HelloWorld.class.getResource("helloworld.config.xml");

        System.out.println("Loading...");

        ConfigurationManager cm = new ConfigurationManager(url);

	    Recognizer recognizer = (Recognizer) cm.lookup("recognizer");
	    Microphone microphone = (Microphone) cm.lookup("microphone");


        /* allocate the resource necessary for the recognizer */
        recognizer.allocate();

        /* the microphone will keep recording until the program exits */
	    
        if (microphone.startRecording())
        {	
			while (true) 
            {
				
				System.out.println("Taking voice input:\n");	  
		 
				Result result = recognizer.recognize();
				if (result != null)
				{
					resultText = result.getBestFinalResultNoFiller();
					System.out.println("You said: " + resultText + "\n");
					
					if (resultText.equalsIgnoreCase("open calculator"))
					{
						try{
							ra.runApp("calculator");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Calculator')");							
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("start calculator"))
					{
						try{
							ra.runApp("calculator");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Calculator')");	
						}
						catch(Exception ae){}
					}
 			
					else if(resultText.equalsIgnoreCase("close calculator"))
					{	 
						try{
							ca.closeApp("calculator");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Calculator')");
						}
						catch(Exception ae){}
					}
					
					else if(resultText.equalsIgnoreCase("stop calculator"))
					{	 
						try{
							ca.closeApp("calculator");
 		    		       	int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Calculator')");
 		       	        }
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("open Player"))
					{
						try{
							ra.runApp("player");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Player')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("start Player"))
					{
						try{
							ra.runApp("player");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Player')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("open media Player"))
					{
						try{
							ra.runApp("player");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Media Player')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("open windows media Player"))
					{
						try{
							ra.runApp("player");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Windows Media Player')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("stop windows media Player"))
					{
						try{
							ca.closeApp("player");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Windows Media Player')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("stop media Player"))
					{
						try{
							ca.closeApp("player");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Media Player')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("close Player"))
					{
						try{
							ca.closeApp("player");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Player')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("stop Player"))
					{
						try{
							ca.closeApp("player");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Player')");
						}
						catch(Exception ae){}
					}
 			
					else if(resultText.equalsIgnoreCase("open paint"))
					{	 
						try{
							ra.runApp("paint");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Paint')");
						}
						catch(Exception ae){}
					}
			
					else if(resultText.equalsIgnoreCase("start paint"))
					{	 
						try{
							ra.runApp("paint");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Paint')");
						}
						catch(Exception ae){}
					}
 			
					else if(resultText.equalsIgnoreCase("close paint"))
					{	 
						try{
							ca.closeApp("paint");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Paint')");
						}
						catch(Exception ae){}
					}
			
					else if(resultText.equalsIgnoreCase("stop paint"))
					{	 
						try{
							ca.closeApp("paint");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Paint')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("open Browser"))
					{
						try{
							ra.runApp("browser");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Browser')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("start Browser"))
					{
						try{
							ra.runApp("browser");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Browser')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("close Browser"))
					{
						try{
							ca.closeApp("browser");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Browser')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("stop Browser"))
					{
						try{
							ca.closeApp("browser");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Browser')");
						}
						catch(Exception ae){}
					}
 			
					else if(resultText.equalsIgnoreCase("open face book"))
					{	 
						try{
							ra.runApp("facebook");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Facebook')");
						}
						catch(Exception ae){}
					}
			
					else if(resultText.equalsIgnoreCase("start face book"))
					{	 
						try{
							ra.runApp("facebook");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Facebook')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("stop face book"))
					{
						try{
							ca.closeApp("facebook");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Facebook')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("close Browser"))
					{
						try{
							ca.closeApp("browser");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Browser')");
						}
						catch(Exception ae){}
					}
			
					else if(resultText.equalsIgnoreCase("open go ogle"))
					{	 
						try{
							ra.runApp("google");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Google')");
						}
						catch(Exception ae){}
					}

					else if(resultText.equalsIgnoreCase("start go ogle"))
					{	 
						try{
							ra.runApp("google");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Google')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("close go ogle"))
					{
						try{
							ca.closeApp("google");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Google')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("stop go ogle"))
					{
						try{
							ca.closeApp("google");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Google')");
						}
						catch(Exception ae){}
					}
			
					else if(resultText.equalsIgnoreCase("open mail"))
					{	 
						try{
							ra.runApp("mail");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Mail')");
						}
						catch(Exception ae){}
					}
			
					else if(resultText.equalsIgnoreCase("start mail"))
					{	 
						try{
							ra.runApp("mail");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Mail')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("close mail"))
					{
						try{
							ca.closeApp("mail");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Mail')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("stop mail"))
					{
						try{
							ca.closeApp("mail");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Mail')");
						}
						catch(Exception ae){}
					}
 		    
					else if (resultText.equalsIgnoreCase("open note pad"))
					{
						try{
							ra.runApp("notepad");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Notepad')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("start note pad"))
					{
						try{
							ra.runApp("notepad");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Notepad')");
						}
						catch(Exception ae){}
					}
					
					else if (resultText.equalsIgnoreCase("close note pad"))
					{
						try{
							ca.closeApp("notepad");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Notepad')");
						}
						catch(Exception ae){}
					}
					
					else if (resultText.equalsIgnoreCase("stop note pad"))
					{
						try{
							ca.closeApp("notepad");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Notepad')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("open word"))
					{
						try{
							ra.runApp("word");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Word')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("start word"))
					{
						try{
							ra.runApp("word");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Word')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("close word"))
					{
						try{
							ca.closeApp("word");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Word')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("stop word"))
					{
						try{
							ca.closeApp("word");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Word')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("start explorer"))
					{
						try{
							ra.runApp("explorer");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Explorer')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("open explorer"))
					{
						try{
							ra.runApp("explorer");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Explorer')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("open my computer"))
					{
						try{
							ra.runApp("explorer");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open My Computer')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("open c drive"))
					{
						try{
							ra.runApp("c drive");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open C drive')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("open d drive"))
					{
						try{
							ra.runApp("d drive");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open D drive')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("close my computer"))
					{
						try{
							ca.closeApp("explorer");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close My Computer')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("close explorer"))
					{
						try{
							ca.closeApp("explorer");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Explorer')");
						}
						catch(Exception ae){}
					}	
 			
					else if (resultText.equalsIgnoreCase("stop explorer"))
					{
						try{
							ca.closeApp("explorer");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Explorer')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("start Excel"))
					{
						try{
							ra.runApp("excel");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Start Excel')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("open Excel"))
					{
						try{
							ra.runApp("excel");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Open Excel')");
						}
						catch(Exception ae){}
					}
 			
					else if (resultText.equalsIgnoreCase("stop Excel"))
					{
						try{
							ca.closeApp("excel");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Stop Excel')");
						}
						catch(Exception ae){}
					}
			
					else if (resultText.equalsIgnoreCase("close Excel"))
					{
						try{
							ca.closeApp("excel");
							int c=da.loadDB("INSERT INTO `log`(`Log`) VALUES ('Close Excel')");
						}
						catch(Exception ae){}
					}
 			
					else if(resultText.equalsIgnoreCase("stop voice input"))
					{
						try{
							System.out.println("Voice input stopped");
							rs=da.getData("select * from log");
							System.out.println("Log file: ");
					        while(rs.next()){
					            String inputcmd = rs.getString("log");
					            System.out.println(inputcmd);
					        }
					        da.close();
							recognizer.deallocate();
							System.exit(1);
						}
						catch(Exception e){}
					}
 			
					else if(resultText.equalsIgnoreCase("stop input"))
					{
						try{
							System.out.println("Voice input stopped");
							rs=da.getData("select * from log");
							System.out.println("Log file: ");
					        while(rs.next()){
					            String inputcmd = rs.getString("log");
					            System.out.println(inputcmd);
					        }
					        da.close();
							recognizer.deallocate();
							System.exit(1);
						}
						catch(Exception e){}
					}
 			
					else if(resultText.equalsIgnoreCase("close input"))
					{
						try{
							System.out.println("Voice input stopped");
							rs=da.getData("select * from log");
							System.out.println("Log file: ");
					        while(rs.next()){
					            String inputcmd = rs.getString("log");
					            System.out.println(inputcmd);
					        }
					        da.close();
							recognizer.deallocate();
							System.exit(1);
						}
						catch(Exception e){}
					}
 			
					else if(resultText.equalsIgnoreCase("close voice input"))
					{
						try{
							System.out.println("Voice input stopped");
							rs=da.getData("select * from log");
							System.out.println("Log file: ");
					        while(rs.next()){
					            String inputcmd = rs.getString("log");
					            System.out.println(inputcmd);
					        }
					        da.close();
							recognizer.deallocate();
							System.exit(1);
						}
						catch(Exception e){}
					}
 			
					else if(resultText.equalsIgnoreCase("close program"))
					{
						try{
							System.out.println("Program closed");
							rs=da.getData("select * from log");
							System.out.println("Log file: ");
					        while(rs.next()){
					            String inputcmd = rs.getString("log");
					            System.out.println(inputcmd);
					        }
					        da.close();
							recognizer.deallocate();
							System.exit(1);
						}
						catch(Exception e){}
					}
					
					else if(resultText.equalsIgnoreCase("stop listening"))
					{
						try{
							System.out.println("Program closed");
							rs=da.getData("select * from log");
							System.out.println("Log file: ");
					        while(rs.next()){
					            String inputcmd = rs.getString("log");
					            System.out.println(inputcmd);
					        }
					        da.close();
							recognizer.deallocate();
							System.exit(1);
						}
						catch(Exception e){}
					}
 			
				}
		    
				else
				{
					System.out.println("Unrecognized voice command.\n");
				}
            }
        }
        
        else
        {
        	System.out.println("Unable to start.\n");
        	recognizer.deallocate();
        	System.exit(1);
	    }
              
        }
        catch (Exception e){
        	System.out.println(e);
        }
    }
}