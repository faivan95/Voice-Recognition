package demo.sphinx.helloworld;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class ProjectFrame extends JFrame
{
	public int status;
	public JButton b;
	public ProjectFrame()
	{
		super("Java Voice Command");
		setSize(1366, 768);
		b = new JButton();
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		add(b, BorderLayout.CENTER);
		b.setIcon(createIcon("Java-Voice-Input.jpg"));
		ButtonSensor bs = new ButtonSensor(this);
		b.addActionListener(bs);
		status = 1;
	}
	
	public ImageIcon createIcon(String path)
	{
		URL url = getClass().getResource(path);
		
		if (url==null)
		{
			System.err.println("Unable to load image "+path);
		}
		ImageIcon icon = new ImageIcon(url);
		return icon;
	}
}

class ButtonSensor implements ActionListener, Runnable
{
	ProjectFrame pf;
	HelloWorld hw;
	Thread buttonthread = null;
	
	public ButtonSensor(ProjectFrame f)
	{
		this.pf = f;
		hw = new HelloWorld(pf);
		buttonthread = new Thread(this);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		buttonthread.start();
	}
	
	public void run()
	{
		pf.b.setIcon(createIcon("Java-Voice-Command-Listening-.jpg"));
		hw.voiceStart();
	}
	
	public ImageIcon createIcon(String path)
	{
		URL url = getClass().getResource(path);
		
		if (url==null)
		{
			System.err.println("Unable to load image "+path);
		}
		ImageIcon icon = new ImageIcon(url);
		return icon;
	}
}
