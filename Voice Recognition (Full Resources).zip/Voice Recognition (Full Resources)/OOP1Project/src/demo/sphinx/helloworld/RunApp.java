package demo.sphinx.helloworld;

import java.io.IOException;

public class RunApp {
	Process p;
	
	RunApp()
	{
		
	}
	
	public void runApp(String s)
	{
		try {
			//Open Calculator
			if (s.equals("calculator"))
			{
				p = Runtime.getRuntime().exec("cmd /c start calc");
			}
			//Open Windows Media Player
			else if (s.equals("player"))
			{
				p = Runtime.getRuntime().exec("cmd /c start wmplayer");
			}
			//Open Paint
			else if (s.equals("paint"))
			{
				p = Runtime.getRuntime().exec("cmd /c start mspaint");
			}
			//Open Browser
			else if (s.equals("browser"))
			{
				p = Runtime.getRuntime().exec("cmd /c start chrome.exe");
			}
			//Open Facebook
			else if (s.equals("facebook"))
			{
				p = Runtime.getRuntime().exec("cmd /c start chrome www.facebook.com");
			}
			//Open Google
			else if (s.equals("google"))
			{
				p = Runtime.getRuntime().exec("cmd /c start chrome www.google.com");
			}
			//Open Mail
			else if (s.equals("mail"))
			{
				p = Runtime.getRuntime().exec("cmd /c start chrome https://mail.google.com");
			}
			//Open Notepad
			else if (s.equals("notepad"))
			{
				p = Runtime.getRuntime().exec("cmd /c start notepad");
			}
			//Open Microsoft Word
			else if (s.equals("word"))
			{
				p = Runtime.getRuntime().exec("cmd /c start winword");
			}
			//Open My Computer
			else if (s.equals("explorer"))
			{
				p = Runtime.getRuntime().exec("cmd /c start explorer");
			}
			//Open C drive
			else if (s.equals("c drive"))
			{
				p = Runtime.getRuntime().exec("explorer.exe C:\\");
			}
			//Open C drive
			else if (s.equals("d drive"))
			{
				p = Runtime.getRuntime().exec("explorer.exe D:\\");
			}
			//Open Excel
			else if (s.equals("excel"))
			{
				p = Runtime.getRuntime().exec("cmd /c start excel");
			}
		}
		catch (IOException ioe)
		{
			System.out.println(ioe);
		}
	}
}
